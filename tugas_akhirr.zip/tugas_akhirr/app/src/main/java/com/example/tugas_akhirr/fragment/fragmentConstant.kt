package com.example.tugas_akhirr.fragment

class fragmentConstant {
    companion object{
        const val FRAGMENT_HOME = 0
        const val FRAGMENT_CREATE = 1
    }
}