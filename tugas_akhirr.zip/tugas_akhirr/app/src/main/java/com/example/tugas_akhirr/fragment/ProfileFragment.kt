package com.example.tugas_akhirr.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.activity.addCallback
import androidx.transition.Visibility
import com.example.tugas_akhirr.R
import com.example.tugas_akhirr.activity.MainActivity2
import com.google.android.material.bottomnavigation.BottomNavigationView

class ProfileFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_profile, container, false)


//        requireActivity().onBackPressedDispatcher.addCallback(this){
//            requireActivity().supportFragmentManager.beginTransaction().replace(R.id.fragmentContainer, HomePageFragment()).commit()
//            val mainActivity2 = activity as MainActivity2
//            val ic_create = mainActivity2.findViewById<ImageView>(R.id.ic_create)
//            ic_create.visibility = View.VISIBLE
//            mainActivity2.activeFragment = HomePageFragment()
//            mainActivity2.btn_click(ic_create)
//
//        }

        return view
    }

}