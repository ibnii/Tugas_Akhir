package com.example.tugas_akhirr.fragment

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Spinner
import android.widget.TextView
import android.widget.TimePicker
import android.widget.Toast
import androidx.activity.addCallback
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat.getSystemService
import androidx.core.content.getSystemService
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.example.tugas_akhirr.R
import com.example.tugas_akhirr.activity.MainActivity2
import com.example.tugas_akhirr.room.Habit
import com.example.tugas_akhirr.room.habitDB
import com.example.tugas_akhirr.room.habitDao
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.util.Calendar
import java.util.concurrent.TimeUnit



class CreateTableFragment : Fragment() {

    @RequiresApi(Build.VERSION_CODES.O)
    lateinit var notificationManager : NotificationManagerCompat
    lateinit var timePicker: TextView
    lateinit var time: TextView
    val Channel_1_ID = "Channel1"
    var day : Int = 0

    //TimePicker Versi
    var hour: Int = 0
    var minute: Int = 0
    val myCalendar = Calendar.getInstance()

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_create_table, container, false)
        val  mainActivity2 = activity as MainActivity2
        val id : Int = mainActivity2.getIdHabit()
        val ic_create = mainActivity2.findViewById<ImageView>(R.id.ic_create)

        time = view.findViewById<TextView>(R.id.time)
        timePicker = view.findViewById<TextView>(R.id.timePicker)
        when (mainActivity2.type){

            Constant.TYPE_UPDATE -> {
                var habsName = view.findViewById<EditText>(R.id.habs_name)
                var habsDesc = view.findViewById<EditText>(R.id.habsDescription)

                CoroutineScope(Dispatchers.IO).launch {
                    val habit = mainActivity2.db.habitDao().getHabit(id)[0]
                    habsName.setText(habit.title)
                    habsDesc.setText(habit.description)
                }

                ic_create.setOnClickListener{
                    if(mainActivity2.activeFragment is CreateTableFragment){
                        val habsName = view.findViewById<EditText>(R.id.habs_name).text.toString()
                        val habsDesc = view.findViewById<EditText>(R.id.habsDescription).text.toString()

                        if (habsName.trim().isNotEmpty()&& habsDesc.trim().isNotEmpty()){
                            mainActivity2.btn_update(ic_create,habsName,habsDesc,day,this.hour,this.minute)
                        }else{
                            replenish()
                        }
                    }
                }
            }
            Constant.TYPE_CREATE -> {

                ic_create.setOnClickListener{
                    if(mainActivity2.activeFragment is CreateTableFragment){
                        val habsName = view.findViewById<EditText>(R.id.habs_name).text.toString()
                        val habsDesc = view.findViewById<EditText>(R.id.habsDescription).text.toString()
                        if (habsName.trim().isNotEmpty()&& habsDesc.trim().isNotEmpty()){
//                            mainActivity2.btn_save(ic_create,habsName,habsDesc,this.day,this.hoursInt)
                            mainActivity2.btn_save(ic_create,habsName,habsDesc,this.day,this.hour,this.minute)
                        }else{
                            replenish()
                        }
                    }
                }
            }
        }



        //ke Home Page via Back Button



        val exit_btn = view.findViewById<ImageView>(R.id.exit)


        exit_btn(exit_btn,ic_create)





        val spinner = view.findViewById<Spinner>(R.id.spinner)
        val choosen = arrayOf("Everyday","Once every Two Days","Once every Three Days")
        val arrayAdp =
            ArrayAdapter<String>(requireContext(),android.R.layout.simple_spinner_dropdown_item,choosen)
        spinner.adapter = arrayAdp



        var selectedItem = spinner.selectedItem.toString()
        when(selectedItem){
            "Everyday" -> {
                day = 1
            }
            "Once every Two Days" -> {
                day = 2
            }
            "Once every Three Days" -> {
                day = 3
            }
        }



        requireActivity().onBackPressedDispatcher.addCallback(this){
            requireActivity().supportFragmentManager.beginTransaction().replace(R.id.fragmentContainer, HomePageFragment()).commit()
            val mainActivity2 = activity as MainActivity2
            val ic_create = mainActivity2.findViewById<ImageView>(R.id.ic_create)
//            Toast.makeText(requireContext(),day, Toast.LENGTH_LONG).show()
            ic_create.setImageResource(R.drawable.ic_plus)
            mainActivity2.activeFragment = HomePageFragment()
            mainActivity2.btn_click(ic_create)
        }

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                val selectedView = view as TextView
                selectedView.gravity = Gravity.CENTER
                selectedView.textAlignment = View.TEXT_ALIGNMENT_CENTER
                val white = ContextCompat.getColor(requireContext(), R.color.white)
                selectedView.setTextColor(white)
                selectedView.setBackgroundResource(R.drawable.xml_bg_tv_createhabs2)

            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                val selectedView = view as TextView
                selectedView.gravity = Gravity.CENTER
                selectedView.textAlignment = View.TEXT_ALIGNMENT_CENTER
                val white = ContextCompat.getColor(requireContext(), R.color.white)
                selectedView.setTextColor(white)
                selectedView.setBackgroundResource(R.drawable.xml_bg_tv_createhabs)
            }
        }

        runTimePicker()





        return view
    }


    private fun updateLabel() {
        time.text = "$hour.$minute"
    }
    private fun runTimePicker(){
        timePicker.setOnClickListener {
            val timeSetListener = TimePickerDialog.OnTimeSetListener { _: TimePicker, hourOfDay: Int, minuteOfHour: Int ->
                myCalendar.set(Calendar.HOUR_OF_DAY, hourOfDay)
                myCalendar.set(Calendar.MINUTE, minuteOfHour)

                // Menyimpan jam dan menit ke dalam variabel -> Database
                this.hour = hourOfDay
                this.minute = minuteOfHour

                updateLabel()
            }
            TimePickerDialog(
                requireContext(), timeSetListener, myCalendar.get(Calendar.HOUR_OF_DAY), myCalendar.get(Calendar.MINUTE), true
            ).show()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            val channel1 = NotificationChannel(
                Channel_1_ID,
                "Channel1",
                NotificationManager.IMPORTANCE_HIGH
            )
            channel1.description = "Contoh Notification Channel1"

            val notificationManager: NotificationManager = getActivity()?.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel1)
        }
    }



    fun exit_btn (imageView: ImageView,ic: ImageView){
        imageView.setOnClickListener {

            replaceFragment(HomePageFragment())

            //Kalo di dibuang maka jalan ke btn_save
            val mainActivity2 = activity as MainActivity2
            mainActivity2.activeFragment = HomePageFragment()
            mainActivity2.btn_click(ic)

            val imageView: ImageView = activity?.findViewById(R.id.ic_create) as ImageView
            imageView.setImageResource(R.drawable.ic_plus)
        }
    }

    private fun replaceFragment(fragment: Fragment) {
        (activity as MainActivity2).supportFragmentManager
            .beginTransaction()
            .replace(R.id.fragmentContainer,fragment)
            .commit()
    }


    fun replenish(){
        Toast.makeText(requireContext(),"Please fill out all fields.", Toast.LENGTH_LONG).show()
    }

    override fun onStart() {
        super.onStart()
        createNotificationChannel()
    }





}
