package com.example.tugas_akhirr.fragment

import android.icu.text.SimpleDateFormat
import android.os.Build
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Switch
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.recyclerview.widget.RecyclerView
import com.example.tugas_akhirr.R
import com.example.tugas_akhirr.activity.MainActivity2
import com.example.tugas_akhirr.adapter.AdapterDateHomePage
import com.example.tugas_akhirr.adapter.AdapterListHabs
import com.example.tugas_akhirr.adapter.adapterHomePage
import com.example.tugas_akhirr.room.Habit
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.YearMonth
import java.util.Calendar
import java.util.Locale

class HomePageFragment : Fragment() {

    lateinit var habitAdapter : AdapterListHabs
    @RequiresApi(Build.VERSION_CODES.O)

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?


    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_home_page, container, false)

        val dateText = view.findViewById<TextView>(R.id.currentDate)
        val lisTime = listOf<String>(
            "All","Morning","Afternoon","Evening","Night","MidNight"
        )
        val mainadapter = adapterHomePage( lisTime )
        val today = LocalDate.now()
        val month = YearMonth.from(today)
        val dates = (1..month.lengthOfMonth()).map {
            LocalDate.of(today.year,today.month,it)
        }
        val dateadapter = AdapterDateHomePage( dates )

        val dateRecyclerView = view.findViewById<RecyclerView>(R.id.date)
        view.findViewById<RecyclerView>(R.id.listTimeRecyclerView).adapter = mainadapter
        dateText.text = getCurrentDate()

        val position = dates.indexOfFirst { it.isEqual(today) }
        dateRecyclerView.scrollToPosition(position)

        dateRecyclerView.adapter = dateadapter




        val listHabit = view.findViewById<RecyclerView>(R.id.listHabit)
        this.habitAdapter = AdapterListHabs(arrayListOf(),object : AdapterListHabs.onAdapterListener{
            override fun onClick(habit: Habit) {
                val mainActivity2 = activity as MainActivity2
                mainActivity2.replaceFragmentWithBack(Habs())
                mainActivity2.setIdHabit(habit.id)
            }
        })

        listHabit.adapter = habitAdapter




        return view
    }

    override fun onStart() {
        super.onStart()
        loadHabit()
    }

    fun getCurrentDate(): String {
        val date = Calendar.getInstance().time
        val format = SimpleDateFormat("MMMM yyyy", Locale("id"))
        return format.format(date)
    }

    fun loadHabit(){
        val mainActivity2 = activity as MainActivity2
        CoroutineScope(Dispatchers.IO).launch {
            val habits = mainActivity2.db.habitDao().getHabits()
//            Log.d("MainActivity","DatabaseRespon: $notes")
            withContext(Dispatchers.Main){
                habitAdapter.setData(habits)
            }
        }
    }





}