package com.example.tugas_akhirr.activity

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.icu.text.CaseMap.Title
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.Toast
import androidx.cardview.widget.CardView
import androidx.core.app.NotificationCompat
import androidx.fragment.app.Fragment
import androidx.work.Data
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.example.tugas_akhirr.R
import com.example.tugas_akhirr.fragment.Constant
import com.example.tugas_akhirr.fragment.CreateTableFragment
import com.example.tugas_akhirr.fragment.Habs
import com.example.tugas_akhirr.fragment.HomePageFragment
import com.example.tugas_akhirr.fragment.ProfileFragment
import com.example.tugas_akhirr.room.Habit
import com.example.tugas_akhirr.room.habitDB
import com.google.android.material.bottomnavigation.BottomNavigationView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.concurrent.TimeUnit


class MainActivity2 : AppCompatActivity() {

    var activeFragment : Fragment = HomePageFragment()
    var type = Constant.TYPE_CREATE;


    val db by lazy { habitDB(this) }

    private var idHabit : Int = 0
    fun setIdHabit(id: Int){
        this.idHabit = id
    }
    fun getIdHabit() : Int{
        return idHabit
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        val navbar_bottom = findViewById<BottomNavigationView>(R.id.navbar)
        val ic_create = findViewById<ImageView>(R.id.ic_create)

        navbar_bottom.setOnItemSelectedListener {
            when(it.itemId){
                R.id.today -> {
                    ic_create.setImageResource(R.drawable.ic_plus)
                    replaceFragment(HomePageFragment())
                    activeFragment = HomePageFragment()
                    ic_create.visibility = View.VISIBLE
                    btn_click(ic_create)
                    true
                }
                R.id.profile -> {
                    ic_create.visibility = View.GONE
                    replaceFragment(ProfileFragment())
                    true
                }

                else -> false
            }
        }

        //Plus CLick
        btn_click(ic_create)
    }

     fun btn_click(ic: ImageView) {
        ic.setOnClickListener {
            if(activeFragment is HomePageFragment){
                activeFragment = CreateTableFragment()
                //ubah ke create
                type = Constant.TYPE_CREATE
                // sedang ada di homePage
                replaceFragmentWithBack(CreateTableFragment())
                ic.setImageResource(R.drawable.ic_done)

            }
        }
    }

//    fun btn_click(ic: ImageView, nama: String = "", deskripsi: String = ""){
//        ic.setOnClickListener {
//            if(activeFragment is HomePageFragment){
//                activeFragment = createTableFragment()
//                //ubah ke create
//                // sedang ada di homePage
//                replaceFragment(createTableFragment())
//                ic.setImageResource(R.drawable.ic_done)
//
//            }else{
//                activeFragment = HomePageFragment()
//                replaceFragment(HomePageFragment())
//                ic.setImageResource(R.drawable.ic_plus)
//
//                Toast.makeText(this, nama,Toast.LENGTH_SHORT).show()
//
////                CoroutineScope(Dispatchers.IO).launch {
////                    db.habitDao().addHabit(
////                        Habit(0,createFragement.getName(),createFragement.getDesc())
////                    )
////                }
//            }
//        }
//    }

    fun btn_save(ic: ImageView, nama: String = "", deskripsi: String = "", day: Int = 1, hours: Int, minutes : Int){
        activeFragment = HomePageFragment()
        replaceFragment(HomePageFragment())
        ic.setImageResource(R.drawable.ic_plus)

        Toast.makeText(this, "Successfully added",Toast.LENGTH_SHORT).show()
        btn_click(ic)
        CoroutineScope(Dispatchers.IO).launch {
            db.habitDao().addHabit(
                Habit(0,nama,deskripsi,day,hours,minutes)
            )
        }
    }
    fun btn_update(ic: ImageView, nama: String = "", deskripsi: String = "", day: Int = 1,hours : Int, minutes : Int){
        activeFragment = HomePageFragment()
        replaceFragment(HomePageFragment())
        ic.setImageResource(R.drawable.ic_plus)

        Toast.makeText(this, "Successfully Updated",Toast.LENGTH_SHORT).show()
        btn_click(ic)
        CoroutineScope(Dispatchers.IO).launch {
            db.habitDao().updateHabit(
                Habit(idHabit,nama,deskripsi,day, hours,minutes)
            )
        }
    }

    override fun onStart() {
        super.onStart()
        var size = 0
        CoroutineScope(Dispatchers.IO).launch {
            size = db.habitDao().getTableSize()
            withContext(Dispatchers.Main) {
                var i = 0
                if (size >= 0){
                    while (i < size) {
//                        Toast.makeText(this@MainActivity2, size.toString(), Toast.LENGTH_LONG).show()
                        scheduleNotification(db.habitDao().getHours()[i],db.habitDao().getTittle()[i],db.habitDao().getMinutes()[i])
                        ++i
                    }
                }
            }
        }
        findViewById<ImageView>(R.id.ic_create).setImageResource(R.drawable.ic_plus)
        //Deafult
        supportFragmentManager
            .beginTransaction()
            .replace(R.id.fragmentContainer,HomePageFragment())
            .commit()
    }

    fun replaceFragment(fragment: Fragment) {
        supportFragmentManager
            .beginTransaction()
            .replace(R.id.fragmentContainer,fragment)
            .commit()
        type = Constant.TYPE_CREATE
    }
    fun replaceFragmentWithBack(fragment: Fragment) {
        supportFragmentManager
            .beginTransaction()
            .replace(R.id.fragmentContainer,fragment)
            .addToBackStack(null)
            .commit()
        type = Constant.TYPE_CREATE
    }
    fun replaceFragmentUpdate(fragment: Fragment) {
        supportFragmentManager
            .beginTransaction()
            .replace(R.id.fragmentContainer,fragment)
            .addToBackStack(null)
            .commit()
        type = Constant.TYPE_UPDATE
    }

    fun scheduleNotification(hours: Int,title: String,minutes: Int){
        val message = title
        val data = Data.Builder()
            .putString("message",message)
            .build()
        val workRequest = PeriodicWorkRequestBuilder<NotificationWorker>(1, TimeUnit.DAYS)
            .setInputData(data)
            .setInitialDelay(calculateDelay(hours,minutes), TimeUnit.MILLISECONDS).build()
        WorkManager.getInstance(this).enqueue(workRequest)
    }
    private fun calculateDelay(hours: Int,minutes: Int): Long {
        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY,hours)
            set(Calendar.MINUTE,minutes)
            set(Calendar.SECOND,0)
        }
        if(target.before(now)){
            target.add(Calendar.DATE,1)
        }
        return target.timeInMillis - now.timeInMillis
    }
}
class NotificationWorker(appContext: Context, workerParams: WorkerParameters):
    Worker(appContext,workerParams){
    override fun doWork(): Result {
        val message = inputData.getString("message") ?: "Waktunya beraktifitas!!"
        sendNotification(message)
        return Result.success()
    }

    private fun sendNotification(message: String) {
        val notificationManager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelID = "pengingat"
        val channelName = "Habit Tracker"
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            val channel = NotificationChannel(channelID,channelName, NotificationManager.IMPORTANCE_HIGH)
            notificationManager.createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(applicationContext,channelID)
            .setContentTitle("Ingat Kegiatan Anda!")
            .setContentText(message)
            .setSmallIcon(R.drawable.ic_plus)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
        notificationManager.notify(0,notification.build())
    }

}
