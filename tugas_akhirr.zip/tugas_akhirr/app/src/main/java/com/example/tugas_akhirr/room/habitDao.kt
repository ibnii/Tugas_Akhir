package com.example.tugas_akhirr.room

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

@Dao
interface habitDao {
    @Insert
    suspend fun addHabit(habit: Habit)

    @Update
    suspend fun updateHabit(habit: Habit)

    @Query("DELETE FROM Habit WHERE id = :habitId")
    suspend fun deleteHabit(habitId: Int)

    @Query("select*from Habit")
    suspend fun getHabits():List<Habit>

    @Query("select*from Habit where id = :habit_id")
    suspend fun getHabit(habit_id:Int):List<Habit>

    @Query("select day from Habit where id = :habit_id")
    suspend fun getHabitDay(habit_id: Int):Int

    @Query("select hours from Habit where id = :habit_id")
    suspend fun getHabitHours(habit_id: Int):Int

    @Query("select minutes from Habit where id = :habit_id")
    suspend fun getHabitMinutes(habit_id: Int):Int

    @Query("SELECT COUNT(*) FROM Habit")
    suspend fun getTableSize(): Int

    @Query("Select hours from Habit")
    suspend fun getHours():List<Int>

    @Query("Select minutes from Habit")
    suspend fun getMinutes():List<Int>

    @Query("Select title from Habit")
    suspend fun getTittle():List<String>
}