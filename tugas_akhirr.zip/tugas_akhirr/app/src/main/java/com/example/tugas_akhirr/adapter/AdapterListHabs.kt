package com.example.tugas_akhirr.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.tugas_akhirr.R
import com.example.tugas_akhirr.room.Habit
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AdapterListHabs(
    val habit: ArrayList<Habit>,
    private val listener: onAdapterListener,
):RecyclerView.Adapter<AdapterListHabs.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return AdapterListHabs.ViewHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.adapter_list_habs, parent, false)
        )
    }


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val habit = habit[position]

        holder.name.text = habit.title

        holder.name.setOnClickListener {
            listener.onClick(habit)
        }
    }

    override fun getItemCount(): Int {
        return habit.size
    }


    class ViewHolder(view: View): RecyclerView.ViewHolder(view){
        val name = view.findViewById<TextView>(R.id.adapter_habit_name)
    }

    fun setData(list:List<Habit>){
        habit.clear()
        habit.addAll(list)
        notifyDataSetChanged()
    }
    interface onAdapterListener{
        fun onClick(habit: Habit)
    }
}
