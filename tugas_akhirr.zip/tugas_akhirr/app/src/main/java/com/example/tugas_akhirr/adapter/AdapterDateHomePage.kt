package com.example.tugas_akhirr.adapter

import android.graphics.Color
import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import com.example.tugas_akhirr.R
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

class AdapterDateHomePage(

    val dates : List<LocalDate>
): RecyclerView.Adapter<AdapterDateHomePage.ViewHolder>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): AdapterDateHomePage.ViewHolder {
        return AdapterDateHomePage.ViewHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.adapter_date_home, parent, false)
        )
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onBindViewHolder(holder: AdapterDateHomePage.ViewHolder, position: Int) {
        val currentDate = dates[position]
        holder.dayTextView.text = currentDate.dayOfWeek.getDisplayName(TextStyle.FULL, Locale.getDefault())
        holder.dateTextView.text = currentDate.format(DateTimeFormatter.ofPattern("dd"))

        val today = LocalDate.now()

        if(currentDate.isEqual(today)){
            holder.layoutDate.setBackgroundResource(R.drawable.xml_bg_create_habit)
            holder.dayTextView.setTextColor(Color.BLACK)
            holder.dateTextView.setTextColor(Color.BLACK)
        }else{
            holder.layoutDate.setBackgroundResource(R.drawable.xml_bg_date)
            holder.dayTextView.setTextColor(Color.WHITE)
            holder.dateTextView.setTextColor(Color.WHITE)
        }
    }

    override fun getItemCount(): Int {
        return dates.size
    }

    class ViewHolder(view: View): RecyclerView.ViewHolder(view){
        val dayTextView: TextView = view.findViewById(R.id.dayTextView)
        val dateTextView: TextView = view.findViewById(R.id.dateTextView)
        val layoutDate : ConstraintLayout= view.findViewById(R.id.DateLayout)
    }
}