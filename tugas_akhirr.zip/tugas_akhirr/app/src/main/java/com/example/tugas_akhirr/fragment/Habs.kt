package com.example.tugas_akhirr.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.example.tugas_akhirr.R
import com.example.tugas_akhirr.activity.MainActivity2
import com.example.tugas_akhirr.room.Habit
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch


class Habs : Fragment() {

    var habit_name : TextView? = null
    var tv_desc : TextView? = null
    var tv_jam : TextView? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view = inflater.inflate(R.layout.fragment_habs, container, false)

        this.habit_name = view.findViewById<TextView>(R.id.habit_name)
        this.tv_desc = view.findViewById<TextView>(R.id.desc_Habs)
        this.tv_jam = view.findViewById<TextView>(R.id.pengingat)


        getHabit()
        val delete = view.findViewById<ImageView>(R.id.delete)
        val edit = view.findViewById<ImageView>(R.id.edit)
        val back_btn = view.findViewById<ImageView>(R.id.back)
        back_btn(back_btn)

        delete(delete)
        edit(edit)

        return view
    }

    fun getHabit(){
        val mainActivity2 = activity as MainActivity2
        CoroutineScope(Dispatchers.IO).launch {
            val habit  = mainActivity2.db.habitDao().getHabit(mainActivity2.getIdHabit())[0]
            habit_name?.text = habit.title
            tv_desc?.text = habit.description
            tv_jam?.text = "Jam : ${habit.hours}\nMenit : ${habit.minutes}"
        }
    }

    fun back_btn(imageView: ImageView){
        imageView.setOnClickListener {
            val mainActivity2 = activity as MainActivity2
            mainActivity2.replaceFragmentWithBack(HomePageFragment())
        }
    }

    fun delete(imageView: ImageView){
        imageView.setOnClickListener {
            val mainActivity2 = activity as MainActivity2
            val alertdialog = AlertDialog.Builder(requireContext()).apply {
                setTitle("Konfirmasi")
                setMessage("Yakin menghapus ${habit_name?.text}")
                setNegativeButton("Batal") { dialogInterface, i ->
                    dialogInterface.dismiss()
                }
                setPositiveButton("Hapus") { dialogInterface, i ->
                    dialogInterface.dismiss()
                    CoroutineScope(Dispatchers.IO).launch {
                        mainActivity2.db.habitDao().deleteHabit(mainActivity2.getIdHabit())
                        //loadNote()
                        mainActivity2.replaceFragment(HomePageFragment())
                    }
                    Toast.makeText(requireContext(),"Succesfully Deleted", Toast.LENGTH_LONG).show()
                }
            }
            alertdialog.show()
        }
    }
    fun edit(imageView: ImageView){
        val mainActivity2 = activity as MainActivity2
        imageView.setOnClickListener {

//            CoroutineScope(Dispatchers.IO).launch{
//                val habit  = mainActivity2.db.habitDao().getHabitHours(mainActivity2.getIdHabit())
//                Toast.makeText(requireContext(),habit.toString(), Toast.LENGTH_LONG).show()
//            }

            mainActivity2.replaceFragmentUpdate(CreateTableFragment())
            mainActivity2.type = Constant.TYPE_UPDATE
            mainActivity2.activeFragment = CreateTableFragment()
//            Toast.makeText(requireContext(),"${mainActivity2.type}", Toast.LENGTH_LONG).show()
            mainActivity2.findViewById<ImageView>(R.id.ic_create).setImageResource(R.drawable.ic_done)
        }
    }

}