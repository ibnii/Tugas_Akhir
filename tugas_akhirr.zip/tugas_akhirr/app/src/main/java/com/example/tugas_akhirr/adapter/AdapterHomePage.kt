package com.example.tugas_akhirr.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.tugas_akhirr.R

class adapterHomePage (
    private val listTime:List<String>
):RecyclerView.Adapter<adapterHomePage.ViewHolder>(){
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.adapter_home_page,parent,false)
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.textView.text = listTime[position]
    }

    override fun getItemCount(): Int {
        return listTime.size
    }

    class ViewHolder(view: View): RecyclerView.ViewHolder ( view ){
        val textView = view.findViewById<TextView>(R.id.textview)
    }
}