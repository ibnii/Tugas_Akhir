package com.example.tugas_akhirr.fragment

class Constant {
    companion object{
        const val TYPE_CREATE = 0
        const val TYPE_UPDATE = 1
    }
}